=== Smart SEO Tool-百度SEO优化插件 ===
Contributors: wbolt,mrkwong
Donate link: https://www.wbolt.com/
Tags: Baidu, SEO, 百度SEO, 搜索引擎优化, SEO插件, SEO优化, 百度搜索优化
Requires at least: 4.8
Tested up to: 5.1.1
Stable tag: 1.1.0
License: GNU General Public License v2.0 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Smart SEO Tool是一款专门针对WordPress开发的智能SEO优化插件，与众多WordPress的SEO插件不一样的是，Smart SEO Tool更加简单易用，帮助站长快速完成WordPress博客/网站的SEO基础优化。

== Description ==

Smart SEO Tool是一款专门针对WordPress开发的智能SEO优化插件，与众多WordPress的SEO插件不一样的是，Smart SEO Tool更加简单易用，帮助站长快速完成WordPress博客/网站的SEO基础优化。全新版本v1.1.0功能更加强大，新增了网站图片、标签列表页、搜索结果页和作者页SEO优化功能。

* 站点首页优化-通过配置WordPress博客/网站的首页标题、关键词和描述，实现首页优化。
* 分类列表页优化-支持站长选择WordPress博客/网站已设置的分类，对每一个分类单独设置标题、关键词和描述。
* 文章图片Title和ALT元描述优化-支持配置图片优化规则，按规则优化图片的标题和ALT元描述。
* 文章页面优化-默认分别读取文章标题、Tag和文章内容(前200个字符)为Title、Keyword和Description。
* 独立页面优化-默认分别读取Page页面标题和文章内容(前200个字符)为Title和Description。
* 搜索列表页优化-使用智能优化规则优化搜索结果页，优化规则详见插件说明文档。
* 标签页优化-使用智能优化规则优化标签结果页，优化规则详见插件说明文档。
* 作者页优化-使用智能优化规则优化标签作者页，优化规则详见插件说明文档。


== Installation ==

FTP安装
1. 上传 `smart seo tool` 插件压缩包目录到 `/wp-content/plugins/`目录.
2. 在 WordPress 插件面板激活 `Smart SEO Tool` 插件.
3. 通过设置->`Smart SEO Tool` 进入插件设置，开启SEO功能，完成首页、分类页的标题、关键词和描述设置，最后保存即可。

仪表盘安装
1. 进入WordPress仪表盘，点击“插件-安装插件”：
关键词搜索“Smart SEO Tool”，找搜索结果中找到“Smart SEO Tool”插件，点击“现在安装”；
或者，如已经下载插件压缩包，则点击“上传插件”-选择“Smart SEO Tool”插件压缩包，点击“现在安装”
2. 安装完毕后，点击激活 `Smart SEO Tool` 插件.
3. 通过设置->`Smart SEO Tool` 进入插件设置，开启SEO功能，完成首页、分类页的标题、关键词和描述设置，最后保存即可。

关于本插件，你可以通过阅读<a href="https://www.wbolt.com/sst-plugin-documentation.html?utm_source=wp&utm_medium=link&utm_campaign=sst" rel="friend" title="插件教程">Smart SEO Tool插件教程</a>学习了解插件安装、设置等详细内容。


== Frequently Asked Questions ==

= 使用Wbolt开发的WordPress是否需要安装该插件? =

不需要。Wbolt开发的WordPress已经在主题设置中整合了Smart SEO Tool功能，且提供更完整的SEO优化功能。

= 安装启用了Smart SEO Tool，是否还可以安装其他SEO插件? =

不可以。WordPress博客网站仅支持启用一款SEO插件，同时启用多个SEO插件会造成冲突。Smart SEO Tool非常简单易用，且符合百度搜索优化规则，推荐安装使用。

= 为什么Smart SEO Tool插件不支持文章页、独立页面、搜索列表、标签页和作者页优化配置? =

Smart SEO Tool已经通过依据搜索引擎标准内置智能优化规则对这些页面执行了优化，我们希望WordPress站长可以通过最少的设置快速实现SEO优化。

== Notes ==

<a href="https://www.wbolt.com/?utm_source=wp&utm_medium=link&utm_campaign=sst" rel="friend" title="SEO优化插件">Smart SEO Tool插件</a>是目前WordPress插件市场中最简单易用的SEO优化插件，但功能又非常强大的SEO插件. 

闪电博（<a href="https://www.wbolt.com/?utm_source=wp&utm_medium=link&utm_campaign=sst" rel="friend" title="闪电博官网">wbolt.com</a>）专注于WordPress主题和插件开发,为中文博客提供更多优质和符合国内需求的主题和插件。此外我们也会分享WordPress相关技巧和教程。

除了百度搜索推送管理插件外，目前我们还开发了以下WordPress插件：

- [百度搜索推送管理](https://wordpress.org/plugins/baidu-submit-link/)
- [WP资源下载管理](https://wordpress.org/plugins/download-info-page/)
- [文章打赏/分享/点赞多合一](https://wordpress.org/plugins/donate-with-qrcode/)
- 更多主题和插件，请访问<a href="https://www.wbolt.com/?utm_source=wp&utm_medium=link&utm_campaign=sst" rel="friend" title="闪电博官网">wbolt.com</a>!

如果你在WordPress主题和插件上有更多的需求，也希望您可以向我们提出意见建议，我们将会记录下来并根据实际情况，推出更多符合大家需求的主题和插件。

致谢！

闪电博团队

== Screenshots ==

1. 站点首页优化截图.
2. 分类列表页优化截图.
3. 图片Title&ALT优化截图.
4. 其他页面优化截图.

== Changelog ==

= 1.1.0 =
* 新增搜索列表页优化功能
* 新增Tag列表页优化功能
* 新增作者页优化功能
* 新增图片SEO优化功能
* 增加插件教程/插件支持等链接入口
* 优化插件设置UI界面

= 1.0.0 =
* 新增SEO功能开关功能
* 新增WordPress首页SEO设置功能
* 新增WordPress文章页和Page页面自动优化规则
* 新增WordPress分类页面SEO设置功能

