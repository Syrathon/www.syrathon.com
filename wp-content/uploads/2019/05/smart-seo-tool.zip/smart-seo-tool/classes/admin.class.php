<?php
/**
 * This was contained in an addon until version 1.0.0 when it was rolled into
 * core.
 *
 * @package    WBOLT
 * @author     WBOLT
 * @since      1.1.0
 * @license    GPL-2.0+
 * @copyright  Copyright (c) 2019, WBOLT
 */

class Smart_SEO_Tool_Admin
{
    public static $name = 'sseot_pack';
    public static $optionName = 'sseot_option';
    public $token = '';


    public static function cnf($key,$default=null){
        static $_push_cnf = array();
        if(!$_push_cnf){

            $_push_cnf = get_option(self::$optionName,array());
        }
        $keys = explode('.',$key);
        $cnf = $_push_cnf;
        $find = false;

        foreach ($keys as $_k){
            if(isset($cnf[$_k])){
                $cnf = $cnf[$_k];
                $find = true;
                continue;
            }
            $find = false;
        }
        if($find){
            return $cnf;
        }

        /*if(isset($_push_cnf[$key])){
            return $_push_cnf[$key];
        }*/

        return $default;

    }

    public function __construct(){





        if(is_admin()){



            //插件设置连接
            add_filter( 'plugin_action_links', array($this,'actionLinks'), 10, 2 );

            add_action( 'admin_menu', array($this,'admin_menu') );

            add_action( 'admin_init', array($this,'admin_init') );

            add_action('admin_enqueue_scripts',array($this,'admin_enqueue_scripts'),1);

            add_filter('plugin_row_meta', array(__CLASS__, 'plugin_row_meta'), 10, 2);

        }else{


            $active = self::cnf('active',0);
            if ($active) {
                //去掉默认标题处理
                remove_action('wp_head', '_wp_render_title_tag', 1);
                //添加seo处理
                add_action('wp_head',array(__CLASS__,'seoTitle') , 1);

                if(self::cnf('img_seo.active',false)){
                    new Smart_SEO_Tool_Images();
                }
            }
        }


    }


    public function admin_enqueue_scripts($hook){
        global $wb_settings_page_hook_bwbs;
        if($wb_settings_page_hook_bwbs != $hook) return;

        wp_enqueue_style('wbs-style-bdsl', plugin_dir_url(SMART_SEO_TOOL_BASE_FILE) . 'assets/wbp_setting.css', array(),SMART_SEO_TOOL_VERSION);
    }
    //seo title, keywords, description
    public static function seoTitle()
    {
        $title = wp_get_document_title();
        $kw = $desc = '';
        $tpls = array('<title>%s</title>', '%s', '%s');
        //$seo = $this->opt('seo');
        if (is_home()) {
            $mata = self::cnf('index',array('','',''));
            if (isset($mata[0]) && $mata[0]) {
                $title = self::formatTitle($mata[0]);
            }
            if (isset($mata[1]) && $mata[1]) {
                $tpls[1] = '<meta name="keywords" content="%s" />';
                $kw = $mata[1];
            }
            if (isset($mata[2]) && $mata[2]) {
                $tpls[2] = '<meta name="description" content="%s" />';
                $desc = $mata[2];
            }

        } else if(is_author()){

           /* 标题: “{author_name}”作者主页 - {sitename}
              关键词: 读取该作者所有文章Top5热门关键词，以英文逗号分隔
              描述:  {author_name}作者主页， {author_name}主要负责{该作者所有文章Top5热门关键词（以顿号分割）}等内容发布。
			  注：{author_name}指作者昵称
            */

            global $authordata,$wpdb;

            $sep = apply_filters('document_title_separator', '-');
            $title = implode($sep, array('“'.get_the_author().'”作者主页', get_bloginfo('name', 'display')));
            //$title = self::formatTitle($title);

            if(is_object($authordata)){

                $top_words = get_user_meta($authordata->ID,'seo_top_keywords',true);
                $time = current_time('timestamp');
                if(!$top_words || $top_words['time']<$time){

                    $sql = "SELECT c.`term_taxonomy_id`,c.term_id,COUNT(1) num FROM $wpdb->posts a,$wpdb->term_relationships r,$wpdb->term_taxonomy c ";
                    $sql .= " WHERE a.post_author=%d AND a.post_status='publish' AND a.post_type='post' AND a.ID=r.object_id AND r.term_taxonomy_id=c.term_taxonomy_id AND c.taxonomy='post_tag'";
                    $sql .= " GROUP BY c.`term_taxonomy_id` ORDER by num DESC LIMIT 5";

                    $sql = "SELECT t.name from $wpdb->terms t,($sql) tt WHERE t.term_id=tt.term_id";

                    $sql = $wpdb->prepare($sql,$authordata->ID);

                    $col = $wpdb->get_col($sql);

                    $top_words = array('time'=>$time + WEEK_IN_SECONDS,'keywords'=>$col);
                    update_user_meta($authordata->ID,'seo_top_keywords',$top_words);
                }

                if($top_words['keywords']){
                    $tpls[1] = '<meta name="keywords" content="%s" />';
                    $kw = implode(',',$top_words['keywords']);
                    $tpls[2] = '<meta name="description" content="%s" />';
                    $desc = '“'.get_the_author().'”作者主页，主要负责'.implode('、',$top_words['keywords']).'等内容发布。';
                }

            }




        } else if(is_search()){

            //$q = get_queried_object();
            //print_r($q);
            global $wp_query,$wpdb;
            /*
            标题: 与“{search_keyword}”匹配搜索结果 - {sitename}
            关键词: {search_keyword}, {search_keyword}相关, {search_keyword}内容, 搜索结果所有文章Top5热门关键词
            描述: 当前页面展示所有与“{search_keyword}”相关的匹配结果，包括搜索结果文章Top5关键词（以顿号分割）等内容。
            注：{search_keyword}指访客搜索关键词
            */
            $sep = apply_filters('document_title_separator', '-');
            $q_kw = get_search_query(false);
            $title = implode($sep, array('与“'.$q_kw.'”匹配的搜索结果', get_bloginfo('name', 'display')));
            //$title = self::formatTitle($title);

            $kws = array($q_kw,$q_kw.'相关',$q_kw.'内容');//array_merge(,$top_words['keywords']);
            $tpls[1] = '<meta name="keywords" content="%s" />';
            $kw = implode(',',$kws);
            $tpls[2] = '<meta name="description" content="%s" />';
            $desc = '当前页面展示所有与“'.$q_kw.'”搜索词相匹配的结果';//.implode('、',$top_words['keywords']);

            if($wp_query->found_posts){
                $post_ids = array();
                foreach ($wp_query->posts as $p){
                    $post_ids[] = $p->ID;
                }
                //print_r($wp_query);

                $post_ids = implode(',',$post_ids);

                $sql = "SELECT tt.term_id,tt.term_taxonomy_id,count(1) num FROM $wpdb->term_relationships r , $wpdb->term_taxonomy tt,$wpdb->terms t where r.object_id IN($post_ids) AND r.term_taxonomy_id=tt.term_taxonomy_id AND tt.taxonomy<>'category' group by tt.term_taxonomy_id order by num DESC LIMIT 5";

                $sql = "SELECT t.name FROM $wpdb->terms t ,($sql) tmp where  tmp.term_id=t.term_id ";


                //echo $sql;
                $col = $wpdb->get_col($sql);
                if($col){

                    $kw .= ','.implode(',',$col);
                    $desc .= ',包括'.implode('、',$col).'等内容。';
                }

            }




        } else if(is_tag()){

            $tag = get_queried_object();

            global $wpdb;
            //print_r($tag);
           /* 标题: “{tag}”相关文章列表 - 站点名称
            关键词: {tag}, {tag}相关, {tag}内容及标签结果文章Top5关键词
            描述: 关于“{tag}”相关内容全站索引列表，包括标签列表页所有结果Top5关键词（以顿号分割）。
            注：{tag}指文章编辑时输入的标签词语*/


            $sep = apply_filters('document_title_separator', '-');
            $title = implode($sep, array('“'.$tag->name.'”相关文章列表', get_bloginfo('name', 'display')));
            //$title = self::formatTitle($title);

            $top_words = get_term_meta($tag->term_id,'seo_top_keywords',true);
            $time = current_time('timestamp');
            if(!$top_words || $top_words['time']<$time){


                //tag 下的所有文章
                $sql = "SELECT p.ID  FROM $wpdb->term_relationships r ,$wpdb->posts p WHERE r.term_taxonomy_id = %d and  r.object_id=p.ID AND p.post_status='publish'";

                //所有文章下的tag，取数量前五
                $sql = "SELECT tt.term_taxonomy_id,tt.term_id,COUNT(1) FROM $wpdb->term_taxonomy tt ,$wpdb->term_relationships rr ,$wpdb->posts pp WHERE tt.term_taxonomy_id=rr.term_taxonomy_id  AND tt.taxonomy<>'category' AND rr.object_id=pp.ID AND pp.ID IN($sql)";
                $sql .= " GROUP BY tt.term_taxonomy_id ORDER BY tt.count DESC LIMIT 5";


                $sql = "SELECT t.name FROM $wpdb->terms t,($sql) tmp WHERE t.term_id=tmp.term_id";

                $sql = $wpdb->prepare($sql,$tag->term_taxonomy_id);

                //echo $sql;exit();
                $col = $wpdb->get_col($sql);

                $top_words = array('time'=>$time + WEEK_IN_SECONDS,'keywords'=>$col);
                update_term_meta($tag->term_id,'seo_top_keywords',$top_words);
            }

            if($top_words['keywords']){
                $kws = array_merge(array($tag->name,$tag->name.'相关',$tag->name.'内容'),$top_words['keywords']);
                $tpls[1] = '<meta name="keywords" content="%s" />';
                $kw = implode(',',$kws);
                $tpls[2] = '<meta name="description" content="%s" />';
                $desc = '关于“'.$tag->name.'”相关内容全站索引列表，包括'.implode('、',$top_words['keywords']).'。';
            }

        } else if (is_category()) {
            $term = get_queried_object();
            $cid = $term->term_id;
            $mata = self::cnf($cid, array('', '', ''));
            if (isset($mata[0]) && $mata[0]) {
                $sep = apply_filters('document_title_separator', '-');
                $title = implode($sep, array($mata[0], get_bloginfo('name', 'display')));
                $title = self::formatTitle($title);
            }
            if (isset($mata[1]) && $mata[1]) {
                $tpls[1] = '<meta name="keywords" content="%s" />';
                $kw = $mata[1];
            }
            if (isset($mata[2]) && $mata[2]) {
                $tpls[2] = '<meta name="description" content="%s" />';
                $desc = $mata[2];
            }
        } else if (is_single()) {

            //kw
            $posttags = get_the_tags();

            if ($posttags) {
                $tags = array();
                foreach ($posttags as $tag) {
                    $tags[] = $tag->name;
                }
                $stags = implode(',', $tags);
                $kw = $stags;
                $tpls[1] = '<meta name="keywords" content="%s" />';
            }
            //desc
            $excerpt = self::excerpt();

            if ($excerpt) {
                $desc = $excerpt;
                $tpls[2] = '<meta name="description" content="%s" />';
            }

        }
        echo sprintf(implode('', $tpls), $title, $kw, $desc);
    }

    //格式化标题
    public static function formatTitle($title)
    {
        $title = wptexturize($title);
        $title = convert_chars($title);
        $title = esc_html($title);
        $title = capital_P_dangit($title);
        return $title;
    }

    //文章摘要
    public static function excerpt()
    {
        $post = get_post();
        if (empty($post)) {
            return '';
        }
        $excerpt = $post->post_excerpt ? $post->post_excerpt : self::trimContent($post->post_content);
        if (!$excerpt) return $excerpt;
        return apply_filters('get_the_excerpt', $excerpt);
    }

    //格式化文章内容
    public static function trimContent($text)
    {
        $text = strip_shortcodes($text);

        $text = str_replace(']]>', ']]&gt;', $text);

        $excerpt_length = apply_filters('excerpt_length', 120);

        $excerpt_more = apply_filters('excerpt_more', ' ' . '[&hellip;]');
        $text = wp_trim_words($text, $excerpt_length, $excerpt_more);

        return $text;
    }



    public static function plugin_row_meta($links,$file){

        $base = plugin_basename(SMART_SEO_TOOL_BASE_FILE);
        if($file == $base) {
            $links[] = '<a href="https://www.wbolt.com/plugins/sst">插件主页</a>';
            $links[] = '<a href="https://www.wbolt.com/sst-plugin-documentation.html">FAQ</a>';
            $links[] = '<a href="https://wordpress.org/support/plugin/smart-seo-tool/">反馈</a>';
        }
        return $links;
    }

    function actionLinks( $links, $file ) {

        if ( $file != plugin_basename(SMART_SEO_TOOL_BASE_FILE) )
            return $links;

        $settings_link = '<a href="'.menu_page_url( self::$name, false ).'">设置</a>';

        array_unshift( $links, $settings_link );

        return $links;
    }

    function admin_menu(){
        global $wb_settings_page_hook_bwbs;
        $wb_settings_page_hook_bwbs = add_options_page(
            'Smart SEO Tool',
            'Smart SEO Tool',
            'manage_options',
            self::$name,
            array($this,'admin_settings')
        );
    }
    function admin_settings(){
        $setting_field = self::$optionName;
        $opt = get_option( self::$optionName ,array());
        include_once( SMART_SEO_TOOL_PATH.'/settings.php' );
    }


    function admin_init(){
        register_setting(  self::$optionName,self::$optionName );
    }

}