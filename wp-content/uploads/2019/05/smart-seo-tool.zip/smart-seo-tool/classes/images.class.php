<?php
class Smart_SEO_Tool_Images {


    private $active_title = 0;
    private $active_alt = 0;
	public function __construct(){

	    $this->active_title = Smart_SEO_Tool_Admin::cnf('img_seo.title');
	    $this->active_alt = Smart_SEO_Tool_Admin::cnf('img_seo.alt');


        if($this->active_title || $this->active_alt){

            add_filter( 'the_content', array( $this, 'handel_images' ), 500 );
            add_filter( 'post_thumbnail_html', array( $this, 'handel_images_featured' ), 500 );
        }

	}

	function handel_images( $content ) {	
		//if(is_single()){

            $post_title = get_the_title();
		    if(preg_match_all('#<img([^>]+)>#is',$content,$match)){

		        foreach($match[0] as $k=>$img){
		            $src_img = $img;
                    $img = str_replace(array('alt=""',"alt=''",'title=""',"title=''"),'',$img);

		            $add_html = '';

                    if($this->active_title && !preg_match('#\s+title=.+?#is',$img)){

                        if($this->active_title=='2'){
                            if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                                $add_html .= ' title="'.esc_attr($name_match[0]).'插图'.($k?'('.$k.')':'').'"';
                            }
                        }else if($post_title){

                            $add_html .= ' title="'.esc_attr($post_title).'插图'.($k?'('.$k.')':'').'"';
                        }
                    }
                    if($this->active_alt && !preg_match('#\s+alt=.+?#is',$img)){

                        if($this->active_alt == '2'){
                            if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                                $add_html .= ' alt="'.esc_attr($name_match[0]).'插图'.($k?'('.$k.')':'').'"';
                            }
                        }else if($post_title){
                            $add_html .= ' alt="'.esc_attr($post_title).'插图'.($k?'('.$k.')':'').'"';
                        }
                    }
                    if(!$add_html){
                        continue;
                    }

                    $new_img = '<img'.$add_html.' '.$match[1][$k].'>';
                    $content = str_replace($src_img,$new_img,$content);
                }//end foreach match

            }//end preg_match image
		//}//end if is_single
		return $content;
	}
	
	function handel_images_featured( $html ) {


	    if(preg_match('#<img([^>]+)>#i',$html,$match)){

	        $img = $match[0];

            $add_html = '';
            $post_title = get_the_title();
            $img = str_replace(array('alt=""',"alt=''",'title=""',"title=''"),'',$img);

            if($this->active_title && !preg_match('#\s+title=.+?#is',$img)){

                if($this->active_title=='2'){
                    if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                        $add_html .= ' title="'.esc_attr($name_match[0]).'插图"';
                    }
                }else if($post_title){

                    $add_html .= ' title="'.esc_attr($post_title).'插图"';
                }
            }
            if($this->active_alt && !preg_match('#\s+alt=.+?#is',$img)){

                if($this->active_alt == '2'){
                    if(preg_match('#/.+?\.(jpg|jpeg|gif|webp|png|bmp)#is',$img,$name_match)){
                        $add_html .= ' alt="'.esc_attr($name_match[0]).'插图"';
                    }
                }else if($post_title){
                    $add_html .= ' alt="'.esc_attr($post_title).'插图"';
                }
            }
            if($add_html){

                $html = '<img'.$add_html.' '.$match[1].'>';
            }

        }//end if preg_match image

	    return $html;

	}	

}