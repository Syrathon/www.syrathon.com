<?php
/**
 * This was contained in an addon until version 1.0.0 when it was rolled into
 * core.
 *
 * @package    WBOLT
 * @author     WBOLT
 * @since      1.1.0
 * @license    GPL-2.0+
 * @copyright  Copyright (c) 2019, WBOLT
 */

$pd_title = 'Smart SEO Tool';
$pd_version = SMART_SEO_TOOL_VERSION;
$pd_code = 'sst-setting';
$pd_index_url = 'https://www.wbolt.com/plugins/sst';
$pd_doc_url = 'https://www.wbolt.com/sst-plugin-documentation.html';

wp_enqueue_script('wbp-js', plugin_dir_url(SMART_SEO_TOOL_BASE_FILE) . 'assets/wbp_setting.js', array(), SMART_SEO_TOOL_VERSION, true);

?>

<div style=" display:none;">
    <svg aria-hidden="true" style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <defs>
            <symbol id="sico-upload" viewBox="0 0 16 13">
                <path d="M9 8v3H7V8H4l4-4 4 4H9zm4-2.9V5a5 5 0 0 0-5-5 4.9 4.9 0 0 0-4.9 4.3A4.4 4.4 0 0 0 0 8.5C0 11 2 13 4.5 13H12a4 4 0 0 0 1-7.9z" fill="#666" fill-rule="evenodd"/>
            </symbol>
            <symbol id="sico-wb-logo" viewBox="0 0 18 18">
                <title>sico-wb-logo</title>
                <path d="M7.264 10.8l-2.764-0.964c-0.101-0.036-0.172-0.131-0.172-0.243 0-0.053 0.016-0.103 0.044-0.144l-0.001 0.001 6.686-8.55c0.129-0.129 0-0.321-0.129-0.386-0.631-0.163-1.355-0.256-2.102-0.256-2.451 0-4.666 1.009-6.254 2.633l-0.002 0.002c-0.791 0.774-1.439 1.691-1.905 2.708l-0.023 0.057c-0.407 0.95-0.644 2.056-0.644 3.217 0 0.044 0 0.089 0.001 0.133l-0-0.007c0 1.221 0.257 2.314 0.643 3.407 0.872 1.906 2.324 3.42 4.128 4.348l0.051 0.024c0.129 0.064 0.257 0 0.321-0.129l2.25-5.593c0.064-0.129 0-0.257-0.129-0.321z"></path>
                <path d="M16.714 5.914c-0.841-1.851-2.249-3.322-4.001-4.22l-0.049-0.023c-0.040-0.027-0.090-0.043-0.143-0.043-0.112 0-0.206 0.071-0.242 0.17l-0.001 0.002-2.507 5.914c0 0.129 0 0.257 0.129 0.321l2.571 1.286c0.129 0.064 0.129 0.257 0 0.386l-5.979 7.264c-0.129 0.129 0 0.321 0.129 0.386 0.618 0.15 1.327 0.236 2.056 0.236 2.418 0 4.615-0.947 6.24-2.49l-0.004 0.004c0.771-0.771 1.414-1.671 1.929-2.7 0.45-1.029 0.643-2.121 0.643-3.279s-0.193-2.314-0.643-3.279z"></path>
            </symbol>
            <symbol id="sico-more" viewBox="0 0 16 16">
                <path d="M6 0H1C.4 0 0 .4 0 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1V1c0-.6-.4-1-1-1M15 0h-5c-.6 0-1 .4-1 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1V1c0-.6-.4-1-1-1M6 9H1c-.6 0-1 .4-1 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1v-5c0-.6-.4-1-1-1M15 9h-5c-.6 0-1 .4-1 1v5c0 .6.4 1 1 1h5c.6 0 1-.4 1-1v-5c0-.6-.4-1-1-1"/>
            </symbol>
            <symbol id="sico-plugins" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M16 3h-2V0h-2v3H8V0H6v3H4v2h1v2a5 5 0 0 0 4 4.9V14H2v-4H0v5c0 .6.4 1 1 1h9c.6 0 1-.4 1-1v-3.1A5 5 0 0 0 15 7V5h1V3z"/>
            </symbol>
            <symbol id="sico-doc" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M15 0H1C.4 0 0 .4 0 1v14c0 .6.4 1 1 1h14c.6 0 1-.4 1-1V1c0-.6-.4-1-1-1zm-1 2v9h-3c-.6 0-1 .4-1 1v1H6v-1c0-.6-.4-1-1-1H2V2h12z"/><path d="M4 4h8v2H4zM4 7h8v2H4z"/>
            </symbol>
        </defs>
    </svg>
</div>

<div id="optionsframework-wrap" class="wbs-wrap wbps-wrap" data-wba-source="<?php echo $pd_code; ?>">
    <div class="wbs-header">
        <svg class="wb-icon sico-wb-logo"><use xlink:href="#sico-wb-logo"></use></svg>
        <span>WBOLT</span>
        <strong><?php echo $pd_title; ?></strong>

        <div class="links">
            <a class="wb-btn" href="<?php echo $pd_index_url; ?>" data-wba-campaign="title-bar" target="_blank">
                <svg class="wb-icon sico-plugins"><use xlink:href="#sico-plugins"></use></svg>
                <span>插件主页</span>
            </a>
            <a class="wb-btn" href="<?php echo $pd_doc_url; ?>" data-wba-campaign="title-bar" target="_blank">
                <svg class="wb-icon sico-doc"><use xlink:href="#sico-doc"></use></svg>
                <span>说明文档</span>
            </a>
        </div>
    </div>

    <div class="wbs-main">
        <form class="wbs-content option-form" id="optionsframework" action="options.php" method="post">
		    <?php
		    settings_fields($setting_field);
		    ?>

            <div class="sc-header">
                <strong>SEO设置</strong>
                <span>搜索引擎优化</span>
            </div>

            <div class="sc-body">
                <table class="wbs-form-table">
                    <tbody>

                    <tr>
                        <th class="row w8em">开启全站SEO</th>
                        <td><input class="wb-switch" type="checkbox" data-target="#J_SEOseting" name="<?php echo $setting_field;?>[active]" <?php echo isset($opt['active']) && $opt['active']?' checked':'';?> value="1" id="seo_active"> <span class="description">若你使用了其他搜索引擎优化插件，请务必先停用插件后启用，以免引起冲突！！！</span></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="default-hidden-box<?php echo isset($opt['active']) && $opt['active']?' active':'';?>" id="J_SEOseting">

			    <?php
			    $item_obj =  isset($opt['index']) ? $opt['index'] : array('','','');
			    $item_name =  $setting_field . '[index]';
			    ?>
                <h3 class="sc-header">
                    <strong>站点首页优化</strong>
                </h3>
                <div class="sc-body">
                    <table class="wbs-form-table">
                        <tbody>
                        <tr>
                            <th class="row w8em">标题</th>
                            <td>

                                <div class="input-with-count">
                                    <input id="<?php echo $item_name . '_0'; ?>" class="wbs-input" data-max="80" data-preview-target="#J_pv_index_title" name="<?php echo $item_name;?>[0]" type="text" value="<?php echo $item_obj[0];?>" placeholder="">
                                    <span class="count"></span>
                                </div>
                                <p class="description">一般不超过80个字符</p>
                            </td>
                        </tr>
                        <tr>
                            <th>关键词</th>
                            <td>
                                <label class="input-with-count mt wb-tags-module">
                                    <input id="<?php echo $item_name . '_1'; ?>" data-max="100" name="<?php echo $item_name;?>[1]" data-tags-value="<?php echo $item_obj[1];?>" type="hidden" value="<?php echo $item_obj[1];?>" placeholder="">
                                    <span class="count">已输入<?php echo strlen($item_obj[1]);?></span>

                                    <div class="wb-tags-ctrl">
                                        <div class="tag-items">
										    <?php
										    if($item_obj[1]){
											    trim($item_obj[1]);
											    $tagArr = explode(',',$item_obj[1]);

											    foreach ( $tagArr as $item ) :
												    ?>
                                                    <div class="tag-item">
                                                        <span><?php echo $item; ?></span>
                                                        <a class="del" data-del-val="<?php echo $item; ?>"></a>
                                                    </div>
											    <?php endforeach; ?>
										    <?php } //endif; ?>
                                        </div>
                                        <input class="wb-tag-input" type="text" placeholder="以逗号或回车分隔">
                                    </div>
                                </label>
                                <p class="description">一般不超过100个字符</p>
                        </tr>
                        <tr>
                            <th>描述</th>
                            <td>
                                <div class="input-with-count mt">
                                    <textarea id="<?php echo $item_name . '_2'; ?>" class="wbs-input" data-max="200" data-preview-target="#J_pv_index_desc" rows="5" cols="42" name="<?php echo $item_name;?>[2]" placeholder=""><?php echo $item_obj[2];?></textarea>
                                    <span class="count"></span>
                                </div>
                                <p class="description">一般不超过200个字符</p>
                            </td>
                            </td>
                        </tr>
                        <tr style="display: <?php echo $item_obj[0] && $item_obj[2] ? 'table-row' : 'none'; ?>;">
                            <th>预览</th>
                            <td>
                                <div class="preview-box">
                                    <div class="pvb-display">
                                        <a class="preview-title" id="J_pv_index_title"><?php echo $item_obj[0];?></a>
                                        <p class="preview-desc" id="J_pv_index_desc"><?php echo $item_obj[2];?></p>
                                        <p class="preview-link"><?php echo esc_url( home_url( '/' ) ); ?></p>
                                    </div>
                                    <div class="pvb-ft">* 搜索引擎收录结果展示预览</div>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <h3 class="sc-header">
                    <strong>分类列表页优化</strong>
                </h3>
                <div class="sc-body">

		            <?php
		            $c_list = get_categories(array('hide_empty'=>0));
		            $tableHTML = '';
		            $site_title = ' - ' . get_bloginfo('name', 'display');

		            if($c_list)foreach($c_list as $k => $o){
			            $f_name = $o->term_id;
			            $o_id = 'seo_'.$f_name;
			            $o_k = $setting_field.'['.$f_name.']';
			            $o_v = isset($opt[$f_name])?$opt[$f_name]:array('','','');

			            $tagsHTML = '';

			            if($o_v[1]){
				            trim($o_v[1]);
				            $tagArr = explode(',',$o_v[1]);

				            foreach ( $tagArr as $item ) :
					            $tagsHTML .= '<div class="tag-item">
                                    <span>' .  $item . '</span>
                                    <a class="del" data-del-val="' . $item .'"></a>
                                </div>';
				            endforeach;
			            }

			            $display = $o_v[0] && $o_v[2] ? 'table-row' : 'none';

			            $tableHTML .='
					    <div class="cate-item mt" id="J_'. $o_id .'">
                            <table class="wbs-form-table">
                                <tbody>
                                    <tr>
                                        <th class="row w8em">标题</th>
                                        <td>
                                            <div class="seo-setitem input-with-count">
                                                <input id="'. $o_id .'_title" class="wbs-input" data-max="80" data-preview-target="#J_targetCate'. $f_name .'Title" name="' . $o_k .'[]" type="text" value="'. $o_v[0] .'" placeholder="">
                                                <span class="count">已输入' . strlen($o_v[0]) . '</span>
                                            </div>
                                            <p class="description">一般不超过80个字符</p>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <th>关键词</th>
                                        <td>
                                            <label class="input-with-count mt wb-tags-module">
                                                <input id="'. $o_id .'_keyWord" name="' . $o_k .'[]" type="hidden" data-max="100" data-tags-value="'. $o_v[1] .'" value="'. $o_v[1] .'" placeholder="">
                                                <span class="count">已输入' . strlen($o_v[1]) . '</span>
                                                
                                                <div class="wb-tags-ctrl">
                                                    <div class="tag-items">'.  $tagsHTML .'</div>
                                                        <input class="wb-tag-input" type="text" placeholder="以逗号或回车分隔">
                                                </div>
                                            </label>
                                            <p class="description">一般不超过100个字符</p>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <th>描述</th>
                                        <td>
                                             <div class="seo-setitem input-with-count mt">
                                                <textarea id="'. $o_id .'_desc" class="wbs-input" data-max="200" data-preview-target="#J_targetCate'. $f_name .'Desc" rows="5" cols="42" name="' . $o_k .'[]" placeholder="">'. $o_v[2] .'</textarea>
                                                <span class="count">已输入' . strlen($o_v[2]) . '</span>
                                            </div>
                                            <p class="description">一般不超过200个字符</p>
                                    </td>
                                    </tr>
                                    
                                    <tr style="display: ' . $display .'; ">
                                        <th>预览</th>
                                        <td>
                                            <div class="preview-box">
                                                <div class="pvb-display">
                                                    <a class="preview-title" id="J_targetCate'. $f_name .'Title">'. $o_v[0] . $site_title .'</a>
                                                    <p class="preview-desc" id="J_targetCate'. $f_name .'Desc">'. $o_v[2] .'</p>
                                                    <p class="preview-link">' . esc_url( home_url( "/" ) ) . '</p>
                                                </div>
                                                <div class="pvb-ft">* 搜索引擎收录结果展示预览</div>
                                             </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>';
			            ?>
		            <?php }
		            ?>


                    <table class="wbs-form-table">
                        <tbody>
                        <tr>
                            <th class="row w8em">请选择分类</th>
                            <td>
					            <?php $dropdown_options = array(
						            'show_option_all' => get_taxonomy( 'category' )->labels->all_items,
						            'hide_empty' => 0,
						            'hierarchical' => 1,
						            'show_count' => 0,
						            'orderby' => 'name',
						            'class' => 'settings-cate-dropdown',
						            'selected' => isset($_GET['cat'])?$_GET['cat']:null
					            );

					            wp_dropdown_categories( $dropdown_options ); ?>

                            </td>
                        </tr>
                        </tbody>
                    </table>

		            <?php echo $tableHTML; ?>
                </div>

                <h3 class="sc-header">
                    <strong>图片Title&ALT优化</strong>
                </h3>
                <div class="sc-body">
                    <table class="wbs-form-table">
                        <?php
                        $img_seo_field = $setting_field.'[img_seo]';
                        $img_seo_val = isset($opt['img_seo'])?$opt['img_seo']:array('active'=>0,'title'=>0,'alt'=>0);
                        ?>
                        <tbody>

                        <tr>
                            <th class="row w8em">开启图片SEO</th>
                            <td><input class="wb-switch" type="checkbox" data-target="#J_imgSEOSettingBox"  name="<?php echo $img_seo_field;?>[active]" <?php echo $img_seo_val['active']?' checked':'';?> value="1" id="img_seo_active"> </td>
                        </tr>
                        </tbody>
                    </table>

                    <table class="wbs-form-table default-hidden-box<?php echo $img_seo_val['active']?' active':'';?>" id="J_imgSEOSettingBox">
                        <tbody>
                        <tr>
                            <th class="row w8em">图片Title</th>
                            <td>
                                <div class="selector-bar">
                                    <label><input class="wbs-radio" type="radio" name="<?php echo $img_seo_field;?>[title]" value="0" <?php echo !$img_seo_val['title'] ?  'checked' : ''; ?>> 关闭</label>
                                    <label><input class="wbs-radio" type="radio" name="<?php echo $img_seo_field;?>[title]" value="1" <?php echo $img_seo_val['title']==1?  'checked' : ''; ?>> 文章标题</label>
                                    <label><input class="wbs-radio" type="radio" name="<?php echo $img_seo_field;?>[title]" value="2" <?php echo $img_seo_val['title']==2?  'checked' : ''; ?>> 图片名称</label>
                                </div>
                                <p class="description">启用后，当图片无Title描述时按配置规则填入Title</p>
                            </td>
                        </tr>
                        <tr>
                            <th class="row w8em">图片ALT描述</th>
                            <td>
                                <div class="selector-bar">
                                    <label><input class="wbs-radio" type="radio" name="<?php echo $img_seo_field;?>[alt]" value="0" <?php echo !$img_seo_val['alt'] ?  'checked' : ''; ?>> 关闭</label>
                                    <label><input class="wbs-radio" type="radio" name="<?php echo $img_seo_field;?>[alt]" value="1" <?php echo $img_seo_val['alt']==1?  'checked' : ''; ?>> 文章标题</label>
                                    <label><input class="wbs-radio" type="radio" name="<?php echo $img_seo_field;?>[alt]" value="2" <?php echo $img_seo_val['alt']==2?  'checked' : ''; ?>> 图片名称</label>
                                </div>
                                <p class="description">启用后，当然图片无Alt描述时按配置规则填入Alt</p>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>

                <h3 class="sc-header">
                    <strong>其他页面优化</strong>
                    <a class="wb-ctrl-btn" id="J_switchDisplayMoreItems" data-active=0>[ + 展开 ]</a>
                </h3>

                <?php
                $item_obj =  isset($opt['index']) ? $opt['index'] : array('','','');
                ?>
                <div class="default-hidden-box" id="J_moreSEOItems">
                    <h4 class="sc-title-sub">
                        <span>文章页优化</span>
                    </h4>
                    <div class="sc-body">
                        <p>主题将按如下规则分别自动匹配每篇post的设定：</p>
                        <ul class="list-li">
                            <li>标题: 文章标题 - 站点名称</li>
                            <li>关键词: 文章编辑时使用的tag</li>
                            <li>描述: 系统自动读取文章内容前200个字符</li>
                        </ul>

                        <div class="preview-box mt">
                            <div class="pvb-display">
                                <a class="preview-title">文章标题<?php echo $site_title; ?></a>
                                <p class="preview-desc">这里将会截取你所发布文章时全文的前200个字符内容作为摘要内容，这仅演示数据，实际将会与你的站点数据为主。</p>
                                <p class="preview-link"><?php echo esc_url( home_url( '/' ) ); ?>xxx</p>
                            </div>
                            <div class="pvb-ft">* 搜索引擎收录结果展示预览，上述为DEMO演示数据</div>
                        </div>
                    </div>

                    <h4 class="sc-title-sub">
                        <span>独立页面优化</span>
                    </h4>
                    <div class="sc-body">
                        <p>主题将按如下规则分别自动匹配每篇Page的设定：</p>
                        <ul class="list-li">
                            <li>标题: 独立页面标题 - 站点名称</li>
                            <li>关键词: 为“空”</li>
                            <li>描述: 系统自动读取文章内容前200个字符</li>
                        </ul>

                        <div class="preview-box mt">
                            <div class="pvb-display">
                                <a class="preview-title">独立页面标题<?php echo $site_title; ?></a>
                                <p class="preview-desc">这里将会截取独立页面内容的前200个字符内容作为摘要内容，这仅演示数据，实际将会与你的站点数据为主。</p>
                                <p class="preview-link"><?php echo esc_url( home_url( '/' ) ); ?>xxx</p>
                            </div>
                            <div class="pvb-ft">* 搜索引擎收录结果展示预览，上述为DEMO演示数据</div>
                        </div>
                    </div>

                    <h4 class="sc-title-sub">
                        <span>搜索列表页优化</span>
                    </h4>
                    <div class="sc-body">
                        <p>主题将按如下规则优化搜索词列表页：</p>
                        <ul class="list-li">
                            <li>标题: 与“{search_keyword}”匹配搜索结果 - 站点名称 </li>
                            <li>关键词: {search_keyword}, {search_keyword}相关, {search_keyword}内容及搜索结果文章Top5热门关键词</li>
                            <li>描述: 当前页面展示所有与“{search_keyword}”相关的匹配结果，包括搜索结果文章Top5关键词（以顿号分割）等内容。</li>
                        </ul>

                        <div class="preview-box mt">
                            <div class="pvb-display">
                                <a class="preview-title">与“WordPress”匹配的搜索结果<?php echo $site_title; ?></a>
                                <p class="preview-desc">当前页面展示所有与“WordPress”搜索词相匹配的结果,包括WordPress、WordPress相关、WordPress插件、WordPres主题等内容。</p>
                                <p class="preview-link"><?php echo esc_url( home_url( '/' ) ); ?>xxx</p>
                            </div>
                            <div class="pvb-ft">* 搜索引擎收录结果展示预览，上述为DEMO演示数据</div>
                        </div>
                    </div>

                    <h4 class="sc-title-sub">
                        <span>标签页优化</span>
                    </h4>
                    <div class="sc-body">
                        <p>主题将按如下规则优化Tag列表页：</p>
                        <ul class="list-li">
                            <li>标题: “{tag}”相关文章列表 - 站点名称</li>
                            <li>关键词: {tag}, {tag}相关, {tag}内容及标签结果文章Top5关键词</li>
                            <li>描述: 关于“{tag}”相关内容全站索引列表，包括{tag}标签列表页所有结果Top5关键词（以顿号分割）。</li>
                        </ul>

                        <div class="preview-box mt">
                            <div class="pvb-display">
                                <a class="preview-title">“WordPress主题”相关文章列表<?php echo $site_title; ?></a>
                                <p class="preview-desc">关于“WordPress主题”相关内容全站索引列表，包括WordPress主题、WordPress主题相关、WordPress主题内容、WordPress企业主题等内容。</p>
                                <p class="preview-link"><?php echo esc_url( home_url( '/' ) ); ?>xxx</p>
                            </div>
                            <div class="pvb-ft">* 搜索引擎收录结果展示预览，上述为DEMO演示数据</div>
                        </div>
                    </div>

                    <h4 class="sc-title-sub">
                        <span>作者页优化</span>
                    </h4>
                    <div class="sc-body">
                        <p>主题将按如下规则优化作者索引页：</p>
                        <ul class="list-li">
                            <li>标题: “{author_name}”作者主页 - {sitename}</li>
                            <li>关键词: 读取该作者所有文章Top5热门关键词</li>
                            <li>描述: {author_name}主页，主要负责{该作者所有文章Top5热门关键词（以顿号分割）}等内容发布。</li>
                        </ul>

                        <div class="preview-box mt">
                            <div class="pvb-display">
                                <a class="preview-title">“WBOLT_COM”作者主页<?php echo $site_title; ?></a>
                                <p class="preview-desc">“WBOLT_COM”作者主页，主要负责WordPress、WordPress教程、WordPress优化、WordPress主机、WordPress免费插件等内容发布。</p>
                                <p class="preview-link"><?php echo esc_url( home_url( '/' ) ); ?>xxx</p>
                            </div>
                            <div class="pvb-ft">* 搜索引擎收录结果展示预览，上述为DEMO演示数据</div>
                        </div>
                    </div>
                </div>
            </div>

            <script type="text/javascript" src="https://www.wbolt.com/wb-api/v1/news/lastest"></script>

            <div class="wb-copyright-bar">
                <div class="wbcb-inner">
                    <a class="wb-logo" href="https://www.wbolt.com" data-wba-campaign="footer" title="WBOLT" target="_blank"><svg class="wb-icon sico-wb-logo"><use xlink:href="#sico-wb-logo"></use></svg></a>
                    <div class="wb-desc">
                        Made By <a href="https://www.wbolt.com" data-wba-campaign="footer" target="_blank">闪电博</a>
                        <span class="wb-version">版本：<?php echo $pd_version;?></span>
                    </div>
                    <div class="ft-links">
                        <a href="https://www.wbolt.com/plugins" data-wba-campaign="footer" target="_blank">免费插件</a>
                        <a href="https://www.wbolt.com/knowledgebase" data-wba-campaign="footer" target="_blank">插件支持</a>
                        <a href="<?php echo $pd_doc_url; ?>" data-wba-campaign="footer" target="_blank">说明文档</a>
                        <a href="https://www.wbolt.com/terms-conditions" data-wba-campaign="footer" target="_blank">服务协议</a>
                        <a href="https://www.wbolt.com/privacy-policy" data-wba-campaign="footer" target="_blank">隐私条例</a>
                    </div>
                </div>
            </div>

            <div class="wbs-footer" id="optionsframework-submit">
                <div class="wbsf-inner">
                    <button class="wbs-btn-primary" type="submit" name="update">保存设置</button>
                </div>
            </div>

        </form>
    </div>
</div>
