<?php
/*
Plugin Name: YouHua-Scrathon
Description: 各种优化
Author: Scrathon工作室
*/
//屏蔽wordpress后台（仪表盘）顶部logo
function annointed_admin_bar_remove() {
global $wp_admin_bar;
/* Remove their stuff */
$wp_admin_bar->remove_menu('wp-logo');
}
add_action('wp_before_admin_bar_render', 'annointed_admin_bar_remove', 0);
//复制文章后弹出提示框
function zm_copyright_tips() {
echo '<script>document.body.oncopy=function(){alert("复制成功！转载请务必保留原文链接，申明来源，谢谢合作！");}</script>';
}
add_action( 'wp_footer', 'zm_copyright_tips', 100 );
//移除后台页面标题中的“ — WordPress”
add_filter('admin_title', 'fanly_remove_admin_title', 10, 2);
function fanly_remove_admin_title($admin_title, $title){
    return $title.' &lsaquo; '.get_bloginfo('name');
}
/**
 * 自定义 WordPress 后台底部的版权和版本信息
 * https://www.wpdaxue.com/change-admin-footer-text.html
 */
add_filter('admin_footer_text', 'left_admin_footer_text');
function left_admin_footer_text($text) {
    // 左边信息
    $text = '<span id="footer-thankyou">感谢使用<a href="https://www.scrathon.xyz/">Scrathon工作室网站</a>进行创作</span>';
    return $text;
}
add_filter('update_footer', 'right_admin_footer_text', 11);
function right_admin_footer_text($text) {
    // 右边信息
    $text = "Copyright ©2018-2019 Scrathon工作室 Powered By Scrathon";
    return $text;
//文章内外链添加go跳转
function the_content_nofollow($content){
    preg_match_all('/<a(.*?)href="(.*?)"(.*?)>/',$content,$matches);
    if($matches){
        foreach($matches[2] as $val){
            if(strpos($val,'://')!==false && strpos($val,home_url())===false && !preg_match('/\.(jpg|jepg|png|ico|bmp|gif|tiff)/i',$val)){
                $content=str_replace("href=\"$val\"", "href=\"".home_url()."/go/?url=$val\" ",$content);
            }
        }
    }
 return $content;
}
add_filter('the_content','the_content_nofollow',999);
//评论者链接添加go跳转
function add_redirect_comment_link($text = ''){
    $text=str_replace('href="', 'href="'.get_option('home').'/go/?url=', $text);
    return $text;
}
add_filter('get_comment_author_link', 'add_redirect_comment_link', 5);
add_filter('comment_text', 'add_redirect_comment_link', 99);
}
?>